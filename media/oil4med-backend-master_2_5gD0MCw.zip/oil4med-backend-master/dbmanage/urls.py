from django.urls import path
from django.urls import include
from dbmanage.views import *

urlpatterns = [
    path('register/', register, name='register'),
    path('login/', login, name='login'),
    path('refresh-token/', refresh_token, name='refresh-token'),
    path('notifications/', include('notifications.urls', namespace='notifications')),
    path('users/', UserList.as_view(), name='user-list'),
    path('users/<int:pk>/', UserDetail.as_view(), name='user-detail'),
    path('farmers/', FarmerList.as_view(), name='farmer-list'),
    path('farmers/<int:pk>/', FarmerDetail.as_view(), name='farmer-detail'),
    path('consumers/', ConsumerList.as_view(), name='consumer-list'),
    path('consumers/<int:pk>/', ConsumerDetail.as_view(), name='consumer-detail'),
    path('oil-mills/', OilMillList.as_view(), name='oilmill-list'),
    path('oil-mills/<int:pk>/', OilMillDetail.as_view(), name='oilmill-detail'),
    path('olive-groves/', OliveGroveList.as_view(), name='olive-grove-list'),
    path('olive-groves/<int:pk>/', OliveGroveDetailAPIView.as_view(), name='olive-grove-detail'),
    path('olive-groves/by-name/<str:name>/', OliveGroveByNameAPIView.as_view(), name='olive-grove-by-name'),
    path('olive-grove/create/', OliveGroveCreateView.as_view(), name='olive-grove-create'),
    path('olive-grove/update/<int:pk>/', OliveGroveUpdateView.as_view(), name='olive-grove-update'),
    path('olive-grove/delete/<int:pk>/', OliveGroveDeleteView.as_view(), name='olive-grove-delete'),
    path('harvests/', HarvestListAPIView.as_view(), name='harvest-list'),
    path('harvests/<int:pk>/', HarvestDetail.as_view(), name='harvest-detail'),
    path('harvest/create/', HarvestCreateView.as_view(), name='harvest-create'),
    path('harvest/update/<int:pk>/', HarvestUpdateView.as_view(), name='harvest-update'),
    path('harvest/delete/<int:pk>/', HarvestDeleteView.as_view(), name='harvest-delete'),
    path('olive-sale-offers/create/', OliveSaleOfferCreateAPIView.as_view(), name='olive_sale_offer_create'),  #POST
    path('olive-sale-offers/update/<int:pk>/', OliveSaleOfferUpdateAPIView.as_view(), name='olive_sale_offer_update'), #PUT
    path('olive-sale-offers/', OliveSaleOfferListAPIView.as_view(), name='olive_sale_offers_list'), #GET
    # # /harvest-sale-offers/?price_min=10&price_max=50&quantity_min=100&quantity_max=500&transportation=1&olives_variety=xxx&sort_by=price_asc
    path('olive-sale-offers/<pk>/details/', OliveSaleOfferDetails.as_view(), name='olive_sale_offer_details'), #GET
    path('olive-sale-offers/<pk>/farmer-profile/', OliveSaleOfferFarmerProfile.as_view(), name='olive_sale_offer_farmer_profile'), #GET
    path('olive-purchase-request/create/', OlivePurchaseRequestCreateView.as_view(), name='olive_purchase_request_create'),  #POST
    path('olive_purchase_request_detail/<int:pk>/', OlivePurchaseRequestDetail.as_view(), name='olive_purchase_request_detail'),
    path('olive-purchase-requests/', OlivePurchaseRequestList.as_view(), name='olive_purchase_request_list'),
    path('olive-purchase-requests/<int:pk>/', OlivePurchaseRequestDetail.as_view(), name='olive_purchase_request_detail'),
    path('approve-olive-purchase-request/<int:pk>/', ApproveOlivePurchaseRequest.as_view(), name='approve_olive_purchase_request'),
    path('confirm-olive-purchase/<int:pk>/', ConfirmOlivePurchase.as_view(), name='confirm_olive_purchase'),
    path('purchased-olive/create/', PurchasedOliveCreateAPIView.as_view(), name='purchased_olive_create' ),
    path('update-purchased-olive/<int:pk>/', PurchasedOliveUpdateView.as_view(), name='update_purchased_olive'),
    path('purchased-olive-list/', PurchasedOliveListView.as_view(), name='purchased_olive_list'),
    path('purchased-olive-detail/<int:pk>/', PurchasedOliveRetrieveAPIView.as_view(), name='purchased_olive_detail'),
    path('machines/', MachineList.as_view(), name='machine-list'),
    path('machines/<int:pk>/', MachineDetail.as_view(), name='machine-detail'),
    # path('extraction-operations/', ExtractionOperationList.as_view(), name='extractionoperation-list'),
    # path('extraction-operations/<int:pk>/', ExtractionOperationDetail.as_view(), name='extractionoperation-detail'),
    # path('storage-areas/', StorageAreaListView.as_view(), name='storagearea-list'),
    # path('storage-areas/create/', StorageAreaCreateView.as_view(), name='storagearea-create'),
    # path('iot-sensors/<int:pk>/', IoTSensorDetailView.as_view(), name='iotsensor-detail'),
    # path('sensor-measurements/', SensorMeasurementListView.as_view(), name='sensormeasurement-list'),
    # path('extracted-oil-productions/<int:pk>/', ExtractedOilProductionDetailView.as_view(),
    #      name='extractedoilproduction-detail'),
    # path('oil-analyses/create/', OilAnalysisCreateView.as_view(), name='oilanalysis-create'),
    # path('oil-purchases/', OilPurchaseListView.as_view(), name='oilpurchase-list'),
    # path('oil-purchases/create/', OilPurchaseCreateView.as_view(), name='oilpurchase-create'),
]
