from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from rest_framework.exceptions import ValidationError


class UserManager(BaseUserManager):
    def create_user(self, email, password=None, name=None, role=None):
        """
        Creates and saves a User with the given email, password, name, and role.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
            name=name,
            role=role,
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, name, role):
        """
        Creates and saves a superuser with the given email, password, name, and role.
        """
        user = self.create_user(
            email,
            password=password,
            name=name,
            role=role,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser):
    ROLE_CHOICES = (
        ('farmer', 'Farmer'),
        ('consumer', 'Consumer'),
        ('oil mill', 'Oil Mill'),
        ('administrator', 'Administrator'),
        ('visitor', 'Visitor'),
    )
    email = models.EmailField(verbose_name='email address', max_length=255, unique=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'role']

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True

    @property
    def is_staff(self):
        return self.is_admin


class Farmer(User):
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)
    address = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        verbose_name_plural = "Farmers"


class Consumer(User):
    pass


class OliveGrove(models.Model):
    name = models.CharField(max_length=50)
    is_owner = models.BooleanField(default=False)
    address = models.CharField(max_length=255)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    trees_age = models.IntegerField()
    area = models.IntegerField()
    area_unit_choices = (
        ('ha', 'Hectare'),
        ('Km2', 'Square Kilometers'),
        ('m2', 'Square Meters'),
    )
    area_unit = models.CharField(max_length=4, choices=area_unit_choices)
    density = models.IntegerField()
    olives_variety = models.CharField(max_length=20)
    soil_type_choices = (
        ('SN', 'Sandy'),
        ('SL', 'Silty'),
        ('C', 'Clay'),
        ('L', 'Loamy'),
    )
    soil_type = models.CharField(max_length=3, choices=soil_type_choices)
    fertilizers_used = models.CharField(max_length=255)
    field_image = models.ImageField(upload_to='images/')
    cropping_choices = (
        ('R', 'Rainfed'),
        ('I', 'Irrigated'),
    )
    cropping_system = models.CharField(max_length=2, choices=cropping_choices)
    practice_choices = (
        ('C', 'Conventional'),
        ('O', 'Organic'),
    )
    practice = models.CharField(max_length=2, choices=practice_choices)
    grove_picture = models.ImageField(upload_to='images/')
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class OilMill(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=50)
    region = models.CharField(max_length=50)
    fax = models.CharField(max_length=20)
    website = models.URLField(max_length=255)
    creation_date = models.DateField()
    transformation_capacity = models.IntegerField()
    transformation_capacity_unit_choices = (
        ('l', 'Liters'),
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    transformation_capacity_unit = models.CharField(max_length=3, choices=transformation_capacity_unit_choices)
    chains_number = models.IntegerField()
    has_lab = models.BooleanField(default=False)
    has_pack_unit = models.BooleanField(default=False)
    storage_capacity = models.IntegerField()
    storage_capacity_unit = models.CharField(max_length=2, choices=transformation_capacity_unit_choices)
    practice_choices = (
        ('C', 'Conventional'),
        ('O', 'Organic'),
    )
    practice = models.CharField(max_length=20, choices=practice_choices)
    quality_certificate = models.CharField(max_length=255)
    agreement_date = models.DateField()
    users = models.ManyToManyField(User, related_name='oil_mills', blank=True)

    def __str__(self):
        return self.name


class Harvest(models.Model):
    harvest_date = models.DateField()
    harvest_method_choices = (
        ('Mn', 'Manual'),
        ('Mc', 'Mechanical'),
        ('B', 'Both'),
    )
    harvest_method = models.CharField(max_length=3, choices=harvest_method_choices)
    quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    olives_color = (
        ('G', 'Green'),
        ('P', 'Purple'),
        ('B', 'Black'),
    )
    maturity_index = models.CharField(max_length=2, choices=olives_color)
    characterization_choices = (
        ('Mono', 'Monovarietal'),
        ('Poly', 'Polyvarietal'),
    )
    characterization = models.CharField(max_length=5, choices=characterization_choices)
    classification_by_maturity = models.BooleanField(default=False)
    containers_choices = (
        ('Bg', 'Fabric bags'),
        ('Pb', 'Plastic bags'),
        ('Px', 'Plastic boxes'),
        ('O', 'Other'),
    )
    containers = models.CharField(max_length=3, choices=containers_choices)
    harvest_picture = models.ImageField(upload_to='images/')
    grove = models.ForeignKey(OliveGrove, on_delete=models.CASCADE)
    harvest_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.harvest_code:
            self.harvest_code = f"{self.harvest_date}-{self.grove.name}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.harvest_code


class OliveSaleOffer(models.Model):
    harvest = models.ForeignKey(Harvest, on_delete=models.CASCADE)
    initial_quantity_for_sell = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    available_quantity_for_sell = models.IntegerField()
    offer_price = models.DecimalField(max_digits=10, decimal_places=2)
    availability_date = models.DateField()
    transport_choices = (
        ('D', 'Delivered'),
        ('R', 'Recovered locally'),
    )
    transportation = models.CharField(max_length=2, choices=transport_choices)
    creation_date = models.DateField()
    update_date = models.DateField()
    status_choices = (
        ('A', 'Available'),
        ('Cl', 'Closed'),
        ('Ca', 'Cancelled'),
    )
    offer_status = models.CharField(max_length=3, choices=status_choices, default='A')
    offer_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.id and self.offer_status == 'A':
            self.available_quantity_for_sell = self.initial_quantity_for_sell
        formatted_date = self.creation_date.strftime('%Y%m%d')
        offer_id = str(self.id).zfill(6)
        if not self.offer_code:
            self.offer_code = f"olive selling-{formatted_date}-{offer_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.offer_code


class OlivePurchaseRequest(models.Model):
    olive_sale_offer = models.ForeignKey(OliveSaleOffer, on_delete=models.CASCADE)
    mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='olive_purchase_requests')
    requested_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    requested_price = models.DecimalField(max_digits=10, decimal_places=2)
    request_date = models.DateField()
    buyer_appreciation = models.IntegerField()
    buyer_feedback = models.CharField(max_length=255)
    status_choices = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected'),
        ('B', 'Bought'),
    )
    request_status = models.CharField(max_length=2, choices=status_choices)
    status_update_date = models.DateField()
    request_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        formatted_date = self.request_date.strftime('%Y%m%d')
        request_id = str(self.id).zfill(6)
        if not self.request_code:
            self.request_code = f"olive purchase-{formatted_date}-{request_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.request_code


class PurchasedOlive(models.Model):
    olive_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    purchase_date = models.DateField()
    olives_variety = models.CharField(max_length=50)
    olives_color = (
        ('G', 'Green'),
        ('P', 'Purple'),
        ('B', 'Black'),
    )
    maturity_index = models.CharField(max_length=2, choices=olives_color)
    characterization_choices = (
        ('Mono', 'Monovarietal'),
        ('Poly', 'Polyvarietal'),
    )
    characterization = models.CharField(max_length=5, choices=characterization_choices)
    classification_by_maturity = models.BooleanField(default=False)
    cropping_choices = (
        ('R', 'Rainfed'),
        ('I', 'Irrigated'),
    )
    cropping_system = models.CharField(max_length=2, choices=cropping_choices)
    practice_choices = (
        ('C', 'Conventional'),
        ('O', 'Organic'),
    )
    practice = models.CharField(max_length=2, choices=practice_choices)
    mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='purchased_olives')
    olive_purchase_request = models.OneToOneField(OlivePurchaseRequest, on_delete=models.CASCADE, blank=True, null=True)


class Machine(models.Model):
    machineId = models.CharField(max_length=100)
    brand = models.CharField(max_length=20)
    constructor = models.CharField(max_length=50)
    purchase_date = models.DateField()
    capacity = models.IntegerField()
    type_choices = (
        ('T', 'Traditional'),
        ('S', 'Super press'),
        ('Co', 'Continuous one phase'),
        ('Ct', 'Continuous two phases'),
    )
    type = models.CharField(max_length=3, choices=type_choices)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='machines')


class ExtractionRequest(models.Model):
    harvest = models.OneToOneField(Harvest, on_delete=models.CASCADE)
    considered_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    requested_price = models.DecimalField(max_digits=10, decimal_places=2)
    request_date = models.DateField()
    method_choices = (
        ('M1', 'Method1'),
        ('M2', 'Method2'),
        ('M3', 'Method3'),
    )
    method = models.CharField(max_length=3, choices=method_choices)
    status_choices = (
        ('P', 'Pending'),
        ('R', 'Responded'),
        ('Cf', 'Confirmed'),
        ('Ca', 'Cancelled'),
    )
    request_status = models.CharField(max_length=2, choices=status_choices)
    status_update_date = models.DateField()
    request_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        formatted_date = self.request_date.strftime('%Y%m%d')
        request_id = str(self.id).zfill(6)
        if not self.request_code:
            self.request_code = f"extraction request-{formatted_date}-{request_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.request_code


class ExtractionOffer(models.Model):
    extraction_request = models.ForeignKey(ExtractionRequest, on_delete=models.CASCADE)
    offered_price = models.DecimalField(max_digits=10, decimal_places=2)
    offer_date = models.DateField()
    status_choices = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected'),
        ('E', 'Extracted'),
    )
    offer_status = models.CharField(max_length=2, choices=status_choices)
    status_update_date = models.DateField()
    offer_code = models.CharField(max_length=255, unique=True, blank=True)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        formatted_date = self.offer_date.strftime('%Y%m%d')
        offer_id = str(self.id).zfill(6)
        if not self.offer_code:
            self.offer_code = f"extraction offer-{formatted_date}-{offer_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.offer_code


class ExtractionOperation(models.Model):
    used_machines = models.ManyToManyField(Machine)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='extractions')
    harvests = models.ManyToManyField(Harvest)
    purchased_olives = models.ManyToManyField(PurchasedOlive)
    extraction_offer = models.OneToOneField(ExtractionOffer, on_delete=models.CASCADE, null=True, blank=True)
    reception_date = models.DateField()
    start_date = models.DateField()
    finish_date = models.DateField()
    olives_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    olives_quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    water_per_100kg = models.IntegerField()
    mixing_duration = models.IntegerField()
    time_unit = models.CharField(max_length=3, default='Mn')
    press_temperature = models.DecimalField(max_digits=5, decimal_places=2)
    filtration_considered = models.BooleanField(default=False)
    separate_mixing_by_variety = models.BooleanField(default=False)
    method_choices = (
        ('M1', 'Method1'),
        ('M2', 'Method2'),
        ('M3', 'Method3'),
    )
    method = models.CharField(max_length=3, choices=method_choices)
    produced_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    produced_quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)

    def clean(self):
        if self.harvests and self.purchased_olives:
            raise ValidationError("An extraction operation cannot derive from both a harvest and a purchased olive.")


class StorageArea(models.Model):
    local_type = models.CharField(max_length=50)
    address = models.CharField(max_length=255)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    container_type = models.CharField(max_length=100)
    container_number = models.CharField(max_length=100)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, null=True, blank=True, related_name='storages')
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, null=True, blank=True, related_name='storages')

    def clean(self):
        if self.oil_mill and self.farmer:
            raise ValidationError("A StorageArea cannot have both an OilMill and a Farmer as owners.")
        if not self.oil_mill and not self.farmer:
            raise ValidationError("A StorageArea must have an owner (OilMill or Farmer).")


class IoTSensor(models.Model):
    sensor_id = models.CharField(max_length=100)
    type = models.CharField(max_length=20)
    constructor = models.CharField(max_length=50)
    deployment_date = models.DateField()
    storage_area = models.ForeignKey(StorageArea, on_delete=models.CASCADE, related_name='sensors')


class SensorMeasurement(models.Model):
    parameter = models.CharField(max_length=20)
    value = models.DecimalField(max_digits=5, decimal_places=3)
    date = models.DateField()
    sensor = models.ForeignKey(IoTSensor, on_delete=models.CASCADE, related_name='measurements')


class Packaging(models.Model):
    packaging_reference = models.CharField(max_length=255)
    packaging_date = models.DateField()
    packaged_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    packaged_quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    type_of_packaging_choices = (
        ('DGbt', 'Dark Glass Bottles'),
        ('TGbt', 'Transparent Glass Bottles'),
        ('Pbt', 'Plastic Bottles'),
        ('T', 'Tin Cans'),
        ('Bx', 'Bag In Box'),
        ('C', 'Ceramic jars'),
    )
    type_of_packaging = models.CharField(max_length=4, choices=type_of_packaging_choices)
    packaging_volume = models.CharField(max_length=50)
    packaging_factory_name = models.CharField(max_length=50)
    factory_address = models.CharField(max_length=255)
    factory_certificate = models.CharField(max_length=255)


class OilProduct(models.Model):
    extraction_operation = models.OneToOneField(ExtractionOperation, on_delete=models.CASCADE, null=True, blank=True)
    production_date = models.DateField()
    creation_cause_choices = (
        ('E', 'Extraction'),
        ('St', 'Storage'),
        ('P', 'Packaging'),
        ('Se', 'Selling'),
    )
    creation_cause = models.CharField(max_length=3, choices=creation_cause_choices)
    produced_quantity = models.IntegerField()
    remaining_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    quality_control_performed = models.BooleanField(default=True)
    olive_oil_type_choices = (
        ('EVOO', 'Extra Virgin olive oil'),
        ('VOO', 'Virgin olive oil'),
        ('L', 'Lampante olive oil'),
        ('R', 'Refined olive oil'),
        ('P', 'Olive pomace oil'),
    )
    oil_quality = models.CharField(max_length=5, choices=olive_oil_type_choices)
    owner_category_choices = (
        ('F', 'Farmer'),
        ('M', 'Oil mill'),
        ('C', 'Consumer'),
    )
    owner_category = models.CharField(max_length=2, choices=owner_category_choices)
    owner = models.CharField(max_length=255, blank=True)
    storage_date = models.DateField()
    stored_quantity = models.IntegerField()
    stored_quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    storage_area = models.OneToOneField(StorageArea, on_delete=models.CASCADE, null=True, blank=True)
    packaging = models.OneToOneField(Packaging, on_delete=models.CASCADE, null=True, blank=True)
    mother_product = models.ForeignKey(
        'self',
        related_name='child_products',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    oil_product_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        cre_date = self.production_date.strftime('%Y%m%d')
        oil_id = str(self.id).zfill(6)
        cause = self.creation_cause
        if not self.oil_product_code:
            self.oil_product_code = f"{cause}-{cre_date}-{oil_id}"
        super().save(*args, **kwargs)

    @property
    def last_analysis(self):
        return self.analysis.last()

    def __str__(self):
        return self.oil_product_code


class OilAnalysis(models.Model):
    analysis_reference = models.CharField(max_length=255)
    analysis_date = models.DateField()
    lab_name = models.CharField(max_length=50)
    lab_address = models.CharField(max_length=255)
    lab_agreement = models.CharField(max_length=255)
    lab_agreement_date = models.DateField()
    fatty_acid = models.CharField(max_length=20)
    acidity = models.CharField(max_length=20)
    peroxide_value = models.CharField(max_length=20)
    UV_absorbance = models.CharField(max_length=20)
    oil_product = models.ForeignKey(OilProduct, on_delete=models.CASCADE, related_name='analysis')


class ServiceRequest(models.Model):
    oil_product = models.ForeignKey(OilProduct, on_delete=models.CASCADE, related_name='requests')
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, related_name='requests')
    considered_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    requested_price = models.DecimalField(max_digits=10, decimal_places=2)
    request_date = models.DateField()
    type_choices = (
        ('S', 'Storage'),
        ('P', 'Packaging'),
        ('A', 'Analysis'),
    )
    service_type = models.CharField(max_length=3, choices=type_choices)
    status_choices = (
        ('P', 'Pending'),
        ('R', 'Responded'),
        ('Cf', 'Confirmed'),
        ('Ca', 'Cancelled'),
    )
    request_status = models.CharField(max_length=2, choices=status_choices)
    status_update_date = models.DateField()
    analysis_choices = (
        ('F', 'Fatty Acid'),
        ('P', 'Peroxide value'),
        ('U', 'UV absorbance'),
        ('A', 'Acidity'),
    )
    analysis_type_1 = models.CharField(max_length=2, choices=analysis_choices, null=True, blank=True)
    analysis_type_2 = models.CharField(max_length=2, choices=analysis_choices, null=True, blank=True)
    analysis_type_3 = models.CharField(max_length=2, choices=analysis_choices, null=True, blank=True)
    analysis_type_4 = models.CharField(max_length=2, choices=analysis_choices, null=True, blank=True)
    type_of_packaging_choices = (
        ('DGbt', 'Dark Glass Bottles'),
        ('TGbt', 'Transparent Glass Bottles'),
        ('Pbt', 'Plastic Bottles'),
        ('T', 'Tin Cans'),
        ('Bx', 'Bag In Box'),
        ('C', 'Ceramic jars'),
    )
    type_of_packaging = models.CharField(max_length=4, choices=type_of_packaging_choices, null=True, blank=True)
    packaging_volume = models.CharField(max_length=50, null=True, blank=True)
    storage_type = models.CharField(max_length=100, null=True, blank=True)
    request_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        formatted_date = self.request_date.strftime('%Y%m%d')
        request_id = str(self.id).zfill(6)
        if not self.request_code:
            self.request_code = f"extraction request-{formatted_date}-{request_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.request_code


class ServiceOffer(models.Model):
    service_request = models.ForeignKey(ExtractionRequest, on_delete=models.CASCADE, related_name='service_offers')
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='service_offers')
    offered_price = models.DecimalField(max_digits=10, decimal_places=2)
    offer_date = models.DateField()
    negotiable_price = models.BooleanField(default=False)
    availability = models.DateField()
    type_choices = (
        ('S', 'Storage'),
        ('P', 'Packaging'),
        ('A', 'Analysis'),
    )
    service_type = models.CharField(max_length=3, choices=type_choices)
    status_choices = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected'),
        ('P', 'Packaged'),
        ('S', 'Stored'),
        ('An', 'Analyzed'),
    )
    offer_status = models.CharField(max_length=3, choices=status_choices)
    status_update_date = models.DateField()
    offer_code = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        formatted_date = self.offer_date.strftime('%Y%m%d')
        offer_id = str(self.id).zfill(6)
        service_type = self.service_type
        if not self.offer_code:
            self.offer_code = f"{service_type}-{formatted_date}-{offer_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.offer_code


class ExtractionServiceProposal(models.Model):
    capacity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    capacity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    type_choices = (
        ('T', 'Traditional'),
        ('S', 'Super press'),
        ('Co', 'Continuous one phase'),
        ('Ct', 'Continuous two phases'),
    )
    machine_type = models.CharField(max_length=3, choices=type_choices)
    practice_choices = (
        ('C', 'Conventional'),
        ('O', 'Organic'),
    )
    practice = models.CharField(max_length=2, choices=practice_choices)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    negotiable_price = models.BooleanField(default=False)
    availability = models.DateField()
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='extraction_proposals')


class PackagingServiceProposal(models.Model):
    packaging_factory_name = models.CharField(max_length=50)
    factory_address = models.CharField(max_length=255)
    factory_certificate = models.CharField(max_length=255)
    type_of_packaging_choices = (
        ('DGbt', 'Dark Glass Bottles'),
        ('TGbt', 'Transparent Glass Bottles'),
        ('Pbt', 'Plastic Bottles'),
        ('T', 'Tin Cans'),
        ('Bx', 'Bag In Box'),
        ('C', 'Ceramic jars'),
    )
    type_of_packaging = models.CharField(max_length=4, choices=type_of_packaging_choices)
    packaging_volume = models.CharField(max_length=50)
    capacity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
        ('b', 'Bottles'),
    )
    capacity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    negotiable_price = models.BooleanField(default=False)
    availability = models.DateField()
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='packaging_proposals')


class AnalysisServiceProposal(models.Model):
    lab_name = models.CharField(max_length=50)
    lab_address = models.CharField(max_length=255)
    lab_agreement = models.CharField(max_length=255)
    fatty_acid = models.BooleanField(default=False)
    sensory_description = models.BooleanField(default=False)
    peroxide_value = models.BooleanField(default=False)
    UV_absorbance = models.BooleanField(default=False)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    negotiable_price = models.BooleanField(default=False)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='analysis_proposals')


class StorageServiceProposal(models.Model):
    storage_type = models.CharField(max_length=100)
    capacity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    capacity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    negotiable_price = models.BooleanField(default=False)
    availability = models.DateField()
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, related_name='storage_proposals')


class OilSaleOffer(models.Model):
    oil_product = models.ForeignKey(OilProduct, on_delete=models.CASCADE, related_name='sale_offers')
    initial_quantity_for_sell = models.IntegerField()
    available_quantity_for_sell = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('l', 'Liters'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    offered_price = models.DecimalField(max_digits=10, decimal_places=2)
    transport_choices = (
        ('D', 'Delivered'),
        ('R', 'Recovered locally'),
    )
    transportation = models.CharField(max_length=2, choices=transport_choices)
    creation_date = models.DateField()
    update_date = models.DateField()
    type_of_packaging_choices = (
        ('DGbt', 'Dark Glass Bottles'),
        ('TGbt', 'Transparent Glass Bottles'),
        ('Pbt', 'Plastic Bottles'),
        ('T', 'Tin Cans'),
        ('Bx', 'Bag In Box'),
        ('C', 'Ceramic jars'),
    )
    type_of_packaging = models.CharField(max_length=4, choices=type_of_packaging_choices)
    packaging_volume = models.CharField(max_length=50)
    status_choices = (
        ('A', 'Available'),
        ('Cl', 'Closed'),
        ('Ca', 'Cancelled'),
    )
    offer_status = models.CharField(max_length=3, choices=status_choices)
    offer_code = models.CharField(max_length=255, unique=True, blank=True)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, null=True, blank=True,
                                 related_name='oil_sale_offers')
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, null=True, blank=True, related_name='oil_sale_offers')
    mother_offer = models.ForeignKey(
        'self',
        related_name='child_offers',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    def clean(self):
        if self.oil_mill and self.farmer:
            raise ValidationError("A sale offer cannot be created by an oil mill and a farmer at the same time.")
        if not self.oil_mill and not self.farmer:
            raise ValidationError("A sale offer must have a creator (OilMill or Farmer).")

    def save(self, *args, **kwargs):
        formatted_date = self.creation_date.strftime('%Y%m%d')
        offer_id = str(self.id).zfill(6)
        if not self.offer_code:
            self.offer_code = f"oil selling-{formatted_date}-{offer_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.offer_code


class OilPurchaseRequest(models.Model):
    oil_sale_offer = models.ForeignKey(OilSaleOffer, on_delete=models.CASCADE)
    requested_quantity = models.IntegerField()
    quantity_unit_choices = (
        ('kg', 'Kilograms'),
        ('t', 'Tonnes'),
    )
    quantity_unit = models.CharField(max_length=3, choices=quantity_unit_choices)
    requested_price = models.DecimalField(max_digits=10, decimal_places=2)
    request_date = models.DateField()
    buyer_category_choices = (
        ('C', 'Consumer'),
        ('M', 'Oil mill'),
    )
    buyer_category = models.CharField(max_length=2, choices=buyer_category_choices)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, null=True, blank=True,
                                 related_name='oil_purchase_requests')
    consumer = models.ForeignKey(Consumer, on_delete=models.CASCADE, null=True, blank=True,
                                 related_name='oil_purchase_requests')
    buyer_appreciation = models.IntegerField()
    buyer_feedback = models.CharField(max_length=255)
    status_choices = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected'),
        ('B', 'Bought'),
    )
    request_status = models.CharField(max_length=2, choices=status_choices)
    status_update_date = models.DateField()
    request_code = models.CharField(max_length=255, unique=True, blank=True)

    def clean(self):
        if self.oil_mill and self.consumer:
            raise ValidationError(
                "A purchase request cannot be created by an oil mill and a consumer at the same time.")
        if not self.oil_mill and not self.consumer:
            raise ValidationError("A purchase request must have a creator (OilMill or Consumer).")

    def save(self, *args, **kwargs):
        formatted_date = self.request_date.strftime('%Y%m%d')
        request_id = str(self.id).zfill(6)
        if not self.request_code:
            self.request_code = f"oil purchase-{formatted_date}-{request_id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.request_code


class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    oil_mill = models.ForeignKey(OilMill, on_delete=models.CASCADE, null=True, blank=True)
    message = models.TextField()
    link = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
