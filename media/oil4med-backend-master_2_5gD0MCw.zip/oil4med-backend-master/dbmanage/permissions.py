from rest_framework.permissions import BasePermission
from rest_framework import permissions


class IsFarmer(BasePermission):
    def has_permission(self, request, view):
        # Check if the user is a farmer
        return request.user.role == 'farmer'


class IsConsumer(BasePermission):
    def has_permission(self, request, view):
        # Check if the user is a consumer
        return request.user.role == 'consumer'


class IsOilMill(BasePermission):
    def has_permission(self, request, view):
        # Check if the user is an oil mill
        return request.user.role == 'oil mill'


class IsAdministrator(BasePermission):
    def has_permission(self, request, view):
        # Check if the user is a administrator
        return request.user.role == 'administrator'


class IsVisitor(BasePermission):
    def has_permission(self, request, view):
        # Check if the user is a visitor
        return request.user.role == 'visitor'


class IsOwnerOfOliveGrove(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Check if the request user is the owner of the olive grove
        return obj.farmer == request.user


class IsOwnerOfHarvest(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Check if the request user is the owner of the olive grove
        return obj.grove.farmer == request.user


class IsOwnerOfPurchasedOlive(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Check if the request user is the owner of the PurchasedOlive object
        return obj.mill == request.user


class IsOwnerOfMachine(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # check if the request user is the owner of the Machine
        return obj.oil_mill == request.user
